sap.ui.define([], function() {
    'use strict';

    return {
        alertPredefinedMethod: function() {
            alert("hello..this is a customer section implementation...!")
        }
    };
});
